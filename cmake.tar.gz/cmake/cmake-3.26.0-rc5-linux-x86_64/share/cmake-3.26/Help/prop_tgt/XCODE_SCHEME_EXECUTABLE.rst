XCODE_SCHEME_EXECUTABLE
-----------------------

.. versionadded:: 3.13

Specify path to executable in the Info section of the generated
Xcode scheme. If not set the schema generator will select the
current target if it is actually executable.

Please refer to the :prop_tgt:`XCODE_GENERATE_SCHEME` target property
documentation to see all Xcode schema related properties.

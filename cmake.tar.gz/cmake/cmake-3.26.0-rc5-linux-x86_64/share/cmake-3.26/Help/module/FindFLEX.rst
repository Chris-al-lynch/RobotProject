.. cmake-module:: ../../Modules/FindFLEX.cmake

.. cmake-module:: ../../Modules/GoogleTest.cmake

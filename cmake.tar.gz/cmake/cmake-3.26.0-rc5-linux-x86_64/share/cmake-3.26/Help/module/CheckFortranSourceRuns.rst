.. cmake-module:: ../../Modules/CheckFortranSourceRuns.cmake
